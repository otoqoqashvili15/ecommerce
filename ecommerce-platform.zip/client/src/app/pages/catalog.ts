import { Component, inject, OnInit, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { ShopApi, AuthService } from '../core';

@Component({
  standalone: true, imports: [FormsModule, RouterLink],
  template: `
  <div style="display:grid;grid-template-columns:240px 1fr;gap:24px">
    <aside style="display:grid;gap:8px;align-content:start">
      <input [(ngModel)]="f.search" placeholder="ძიება..." (keyup.enter)="load(1)">
      <select [(ngModel)]="f.categoryId" (change)="load(1)">
        <option [ngValue]="null">ყველა კატეგორია</option>
        @for (c of flat(); track c.id) { <option [ngValue]="c.id">{{c.label}}</option> }
      </select>
      <select [(ngModel)]="f.brand" (change)="load(1)">
        <option [ngValue]="null">ყველა ბრენდი</option>
        @for (b of brands(); track b) { <option [value]="b">{{b}}</option> }
      </select>
      <div style="display:flex;gap:4px"><input type="number" [(ngModel)]="f.minPrice" placeholder="მინ"><input type="number" [(ngModel)]="f.maxPrice" placeholder="მაქს"></div>
      <label><input type="checkbox" [(ngModel)]="f.inStock"> მხოლოდ მარაგში</label>
      <select [(ngModel)]="f.sort"><option value="">სახელით</option><option value="price_asc">ფასი ↑</option><option value="price_desc">ფასი ↓</option><option value="newest">უახლესი</option></select>
      <button (click)="load(1)">გაფილტვრა</button>
    </aside>
    <section>
      @if (recs().length && auth.user()) { <h3>შენთვის</h3><div style="display:flex;gap:8px;overflow:auto">@for (p of recs(); track p.id) { <small style="border:1px solid #ddd;padding:6px">{{p.name}}</small> }</div> }
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:16px;margin-top:12px">
        @for (p of data().items; track p.id) {
          <article style="border:1px solid #ddd;border-radius:8px;padding:12px">
            @if (p.images[0]) { <img [src]="p.images[0]" style="width:100%;height:140px;object-fit:cover"> }
            <h4><a [routerLink]="['/product', p.id]">{{p.name}}</a></h4><small>{{p.brand}} · ⭐ {{p.averageRating ?? p.avgRating}} ({{p.reviewCount}})</small>
            <p>
              @if (p.discountPercent > 0) { <s>{{p.price}} ₾</s> <b style="color:#b91c1c">{{p.finalPrice}} ₾ (-{{p.discountPercent}}%)</b> } @else { <b>{{p.price}} ₾</b> }
            </p>
            <button (click)="add(p)" [disabled]="p.stockQuantity==0">{{p.stockQuantity==0 ? 'არ არის' : 'კალათაში'}}</button>
            <button (click)="wish(p)">♡</button>
          </article>
        }
      </div>
      <p>სულ {{data().total}} · გვერდი {{data().page}}
        <button (click)="load(data().page-1)" [disabled]="data().page<=1">←</button>
        <button (click)="load(data().page+1)" [disabled]="data().page*data().pageSize>=data().total">→</button></p>
      @if (msg) { <p>{{msg}}</p> }
    </section>
  </div>`
})
export class CatalogComponent implements OnInit {
  api = inject(ShopApi); auth = inject(AuthService);
  f: any = { search: '', categoryId: null, brand: null, minPrice: null, maxPrice: null, inStock: false, sort: '', page: 1, pageSize: 12 };
  data = signal<any>({ items: [], total: 0, page: 1, pageSize: 12 });
  brands = signal<string[]>([]); flat = signal<any[]>([]); recs = signal<any[]>([]); msg = '';
  ngOnInit() {
    this.api.brands().subscribe(this.brands.set);
    this.api.categories().subscribe(t => { const out: any[] = []; const walk = (n: any[], d: number) => n.forEach(c => { out.push({ id: c.id, label: '— '.repeat(d) + c.name }); walk(c.children, d + 1); }); walk(t, 0); this.flat.set(out); });
    if (this.auth.user()) this.api.recommendations().subscribe(this.recs.set);
    this.load(1);
  }
  load(page: number) { this.f.page = page; this.api.products(this.f).subscribe(this.data.set); }
  add(p: any) { if (!this.auth.user()) { this.msg = 'გთხოვთ შეხვიდეთ სისტემაში'; return; } this.api.addToCart(p.id).subscribe({ next: () => this.msg = 'დაემატა კალათაში', error: e => this.msg = e.error }); }
  wish(p: any) { if (this.auth.user()) this.api.wishlistAdd(p.id).subscribe(() => this.msg = 'დაემატა სურვილების სიაში'); }
}
