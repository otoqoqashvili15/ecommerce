import { Component, inject, OnInit, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { AuthService, ShopApi } from '../core';

@Component({
  standalone: true, imports: [FormsModule, RouterLink],
  template: `
  @if (p(); as p) {
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:24px">
      <div>@for (i of p.images; track i) { <img [src]="i" style="width:100%;margin-bottom:8px"> }</div>
      <div>
        <h2>{{p.name}}</h2><p>{{p.brand}} · {{p.categoryName}} · ⭐ {{p.avgRating}} ({{p.reviewCount}})</p>
        <p>@if (p.discountPercent>0) { <s>{{p.price}} ₾</s> <b style="color:#b91c1c;font-size:1.4em">{{p.finalPrice}} ₾</b> } @else { <b style="font-size:1.4em">{{p.price}} ₾</b> }</p>
        <p>{{p.description}}</p>
        <table>@for (s of specs(p); track s[0]) { <tr><td style="padding-right:16px"><b>{{s[0]}}</b></td><td>{{s[1]}}</td></tr> }</table>
        <p>მარაგი: {{p.stockQuantity}}</p>
        <button (click)="add(p)" [disabled]="p.stockQuantity==0">კალათაში</button> <button (click)="wish(p)">♡ სურვილების სია</button>
        @if (msg) { <p>{{msg}}</p> }
      </div>
    </div>
    <h3>მიმოხილვები</h3>
    @if (auth.user()) {
      <div style="display:flex;gap:6px"><select [(ngModel)]="rating">@for (r of [5,4,3,2,1]; track r) { <option [ngValue]="r">{{r}} ⭐</option> }</select>
      <input [(ngModel)]="comment" placeholder="კომენტარი" style="flex:1"><button (click)="review(p.id)">გაგზავნა</button></div> }
    @for (r of reviews(); track r.id) { <p><b>{{r.userName}}</b> · {{r.rating}} ⭐<br>{{r.comment}}</p> } @empty { <p>მიმოხილვები ჯერ არ არის</p> }
    <h3>მსგავსი პროდუქტები</h3>
    <div style="display:flex;gap:12px">@for (s of similar(); track s.id) { <a [routerLink]="['/product', s.id]" style="border:1px solid #ddd;padding:8px">{{s.name}}<br>{{s.finalPrice}} ₾</a> }</div>
  }`
})
export class ProductComponent implements OnInit {
  api = inject(ShopApi); auth = inject(AuthService); route = inject(ActivatedRoute);
  p = signal<any>(null); reviews = signal<any[]>([]); similar = signal<any[]>([]); rating = 5; comment = ''; msg = '';
  specs(p: any) { return Object.entries(p.specifications); }
  ngOnInit() {
    this.route.paramMap.subscribe(m => { const id = +m.get('id')!;
      this.api.product(id).subscribe(this.p.set); this.api.reviews(id).subscribe(this.reviews.set); this.api.similar(id).subscribe(this.similar.set); });
  }
  add(p: any) { this.api.addToCart(p.id).subscribe({ next: () => this.msg = 'დაემატა კალათაში', error: e => this.msg = typeof e.error === 'string' ? e.error : 'შედით სისტემაში' }); }
  wish(p: any) { this.api.wishlistAdd(p.id).subscribe({ next: () => this.msg = 'დაემატა სურვილების სიაში', error: () => this.msg = 'შედით სისტემაში' }); }
  review(id: number) { this.api.addReview(id, this.rating, this.comment).subscribe({ next: () => { this.comment = ''; this.api.reviews(id).subscribe(this.reviews.set); }, error: e => this.msg = typeof e.error === 'string' ? e.error : 'შეცდომა' }); }
}
