import { Component, inject, OnInit, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { AuthService, ShopApi } from '../core';

@Component({
  standalone: true, imports: [FormsModule, RouterLink],
  template: `
  <h2>პროფილი</h2>
  <div style="display:grid;gap:6px;max-width:340px">
    <input [(ngModel)]="u.fullName" placeholder="სახელი გვარი"><input [(ngModel)]="u.phone" placeholder="ტელეფონი">
    <input [(ngModel)]="pw" type="password" placeholder="ახალი პაროლი (არასავალდებულო)">
    <button (click)="saveProfile()">შენახვა</button>@if (msg) { <small>{{msg}}</small> }
  </div>
  <h2>მისამართების წიგნაკი</h2>
  @for (a of addresses(); track a.id) { <div>{{a.label}}: {{a.city}}, {{a.street}} {{a.isDefault ? '★' : ''}} <button (click)="delAddr(a.id)">✕</button></div> }
  <div style="display:flex;gap:6px;margin:6px 0"><input [(ngModel)]="na.label" placeholder="სახელი"><input [(ngModel)]="na.city" placeholder="ქალაქი"><input [(ngModel)]="na.street" placeholder="ქუჩა">
    <label><input type="checkbox" [(ngModel)]="na.isDefault"> ძირითადი</label><button (click)="addAddr()">დამატება</button></div>
  <h2>სურვილების სია</h2>
  @for (p of wishlist(); track p.id) { <div><a [routerLink]="['/product', p.id]">{{p.name}}</a> — {{p.finalPrice}} ₾
    <button (click)="cart(p.id)">კალათაში</button> <button (click)="unwish(p.id)">✕</button></div> } @empty { <p>ცარიელია</p> }
  <h2>შეკვეთების ისტორია / თვალყური</h2>
  @for (o of orders(); track o.id) { <details><summary>#{{o.id}} · {{o.createdAt}} · <b>{{o.status}}</b> · {{o.totals.total}} ₾</summary>
    @for (i of o.items; track i.productId) { <div>{{i.productName}} × {{i.quantity}} — {{i.unitPrice}} ₾</div> }
    <small>{{o.deliveryMethod}} · {{o.shippingAddress}}</small></details> } @empty { <p>შეკვეთები არ გაქვთ</p> }`
})
export class AccountComponent implements OnInit {
  api = inject(ShopApi); auth = inject(AuthService);
  u: any = {}; pw = ''; msg = ''; na: any = { label: 'Home', city: '', street: '', isDefault: false };
  addresses = signal<any[]>([]); wishlist = signal<any[]>([]); orders = signal<any[]>([]);
  ngOnInit() { this.api.me().subscribe(u => this.u = u); this.loadAll(); }
  loadAll() { this.api.addresses().subscribe(this.addresses.set); this.api.wishlist().subscribe(this.wishlist.set); this.api.orders().subscribe(this.orders.set); }
  saveProfile() {
    this.api.updateUser(this.u.id, { fullName: this.u.fullName, phone: this.u.phone, newPassword: this.pw || null }).subscribe({
      next: r => { this.msg = 'შენახულია'; this.pw = ''; this.auth.user.set(r); localStorage.setItem('user', JSON.stringify(r)); }, error: e => this.msg = typeof e.error === 'string' ? e.error : 'შეცდომა' });
  }
  addAddr() { this.api.addAddress(this.na).subscribe(() => { this.na = { label: 'Home', city: '', street: '', isDefault: false }; this.loadAll(); }); }
  delAddr(id: number) { this.api.deleteAddress(id).subscribe(() => this.loadAll()); }
  unwish(id: number) { this.api.wishlistRemove(id).subscribe(() => this.loadAll()); }
  cart(id: number) { this.api.addToCart(id).subscribe(() => this.msg = 'დაემატა კალათაში'); }
}
