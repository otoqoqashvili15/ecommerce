import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../core';

@Component({
  standalone: true, imports: [FormsModule],
  template: `
  <h2>{{reg ? 'რეგისტრაცია' : 'შესვლა'}}</h2>
  <form (ngSubmit)="submit()" style="display:grid;gap:8px;max-width:320px">
    @if (reg) { <input [(ngModel)]="fullName" name="n" placeholder="სახელი გვარი" required> }
    <input [(ngModel)]="email" name="e" type="email" placeholder="ელფოსტა" required>
    <input [(ngModel)]="password" name="p" type="password" placeholder="პაროლი (მინ. 8)" minlength="8" required>
    <button>{{reg ? 'რეგისტრაცია' : 'შესვლა'}}</button>
    <a href="#" (click)="reg=!reg;$event.preventDefault()">{{reg ? 'უკვე მაქვს ანგარიში' : 'ახალი ანგარიში'}}</a>
    @if (error) { <p style="color:#b91c1c">{{error}}</p> }
  </form>`
})
export class LoginComponent {
  auth = inject(AuthService); router = inject(Router);
  reg = false; email = ''; password = ''; fullName = ''; error = '';
  submit() {
    const o = this.reg ? this.auth.register({ email: this.email, password: this.password, fullName: this.fullName }) : this.auth.login(this.email, this.password);
    o.subscribe({ next: r => { this.auth.save(r); this.router.navigate(['/']); }, error: e => this.error = typeof e.error === 'string' ? e.error : 'შეცდომა' });
  }
}
