import { Component, inject, OnInit, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AuthService, ShopApi } from '../core';

@Component({
  standalone: true, imports: [FormsModule],
  template: `
  <h2>ადმინისტრირების პანელი</h2>
  <div style="display:flex;gap:8px;margin-bottom:16px">
    @for (t of tabs; track t[0]) { <button (click)="tab=t[0]" [style.font-weight]="tab==t[0]?'bold':'normal'">{{t[1]}}</button> }
  </div>
  @if (msg) { <p style="background:#fef3c7;padding:6px">{{msg}}</p> }

  @if (tab=='dash') {
    @if (stats(); as s) { <p>შემოსავალი: <b>{{s.totalRevenue}} ₾</b> · შეკვეთები: <b>{{s.totalOrders}}</b> · მომხმარებლები: <b>{{s.customers}}</b></p>
      <h4>ტოპ პროდუქტები (30 დღე)</h4>@for (t of s.topProducts; track t.productId) { <div>{{t.productName}} — {{t.units}} ც. / {{t.revenue}} ₾</div> }
      <h4>დღიური გაყიდვები</h4>@for (d of s.daily; track d.date) { <div style="display:flex;gap:8px"><span style="width:90px">{{d.date.substring(0,10)}}</span><div [style.width.px]="d.revenue/ scale(s)" style="background:#3b82f6;height:14px"></div>{{d.revenue}} ₾</div> } }
    <h4>შეტყობინებები</h4>
    @for (n of notes(); track n.id) { <div [style.opacity]="n.isRead?.5:1">⚠ {{n.message}} @if (!n.isRead) { <button (click)="api.readNote(n.id).subscribe(()=>load())">✓</button> }</div> }
    <h4>დაბალი მარაგი</h4>@for (p of low(); track p.id) { <div>{{p.name}} — {{p.stockQuantity}}</div> } @empty { <p>არაფერი</p> }
  }

  @if (tab=='products') {
    <div style="display:grid;gap:6px;max-width:460px;border:1px solid #ddd;padding:12px;margin-bottom:12px">
      <b>{{editId ? 'რედაქტირება #'+editId : 'ახალი პროდუქტი'}}</b>
      <input [(ngModel)]="p.name" placeholder="სახელი"><textarea [(ngModel)]="p.description" placeholder="აღწერა"></textarea>
      <input [(ngModel)]="p.brand" placeholder="ბრენდი"><input [(ngModel)]="p.sku" placeholder="SKU">
      <input type="number" [(ngModel)]="p.price" placeholder="ფასი">
      <select [(ngModel)]="p.categoryId">@for (c of flat(); track c.id) { <option [ngValue]="c.id">{{c.label}}</option> }</select>
      <input type="number" [(ngModel)]="p.stockQuantity" placeholder="მარაგი"><input type="number" [(ngModel)]="p.minStockThreshold" placeholder="მინ. ზღვარი">
      <textarea [(ngModel)]="imgs" placeholder="ფოტოების URL-ები (თითო ხაზზე)"></textarea>
      <textarea [(ngModel)]="specs" placeholder="მახასიათებლები: გასაღები=მნიშვნელობა (თითო ხაზზე)"></textarea>
      <label><input type="checkbox" [(ngModel)]="p.isActive"> აქტიური</label>
      <div><button (click)="saveProduct()">შენახვა</button> @if (editId) { <button (click)="resetProduct()">გაუქმება</button> }</div>
    </div>
    @for (x of products(); track x.id) { <div>#{{x.id}} {{x.name}} · {{x.price}} ₾ · მარაგი {{x.stockQuantity}}
      <button (click)="editProduct(x)">✎</button> <button (click)="delProduct(x.id)">🗑</button></div> }
  }

  @if (tab=='cats') {
    <div style="display:flex;gap:6px"><input [(ngModel)]="cn" placeholder="კატეგორიის სახელი">
      <select [(ngModel)]="cp"><option [ngValue]="null">— ძირითადი —</option>@for (c of flat(); track c.id) { <option [ngValue]="c.id">{{c.label}}</option> }</select>
      <button (click)="addCat()">დამატება</button></div>
    @for (c of flat(); track c.id) { <div>{{c.label}} <button (click)="renameCat(c)">✎</button> <button (click)="delCat(c.id)">🗑</button></div> }
  }

  @if (tab=='camps') {
    <div style="display:grid;gap:6px;max-width:420px;border:1px solid #ddd;padding:12px;margin-bottom:12px">
      <input [(ngModel)]="c.name" placeholder="კამპანიის სახელი"><input type="number" [(ngModel)]="c.percent" placeholder="ფასდაკლება %">
      <label>დაწყება <input type="datetime-local" [(ngModel)]="c.startsAt"></label><label>დასრულება <input type="datetime-local" [(ngModel)]="c.endsAt"></label>
      <input [(ngModel)]="cids" placeholder="პროდუქტის ID-ები მძიმით: 1,2,3">
      <label><input type="checkbox" [(ngModel)]="c.enabled"> ჩართულია</label><button (click)="saveCamp()">შენახვა</button></div>
    @for (x of camps(); track x.id) { <div>{{x.name}} · -{{x.percent}}% · {{x.startsAt.substring(0,16)}} → {{x.endsAt.substring(0,16)}} · {{x.isActive ? '🟢 აქტიური' : '⚪ არააქტიური'}} · პროდუქტები: {{x.productIds.join(',')}}
      <button (click)="delCamp(x.id)">🗑</button></div> }
  }

  @if (tab=='orders') {
    @for (o of orders(); track o.id) { <div>#{{o.id}} · {{o.createdAt.substring(0,16)}} · {{o.totals.total}} ₾ · {{o.shippingAddress}} ·
      <select [ngModel]="o.status" (ngModelChange)="api.setStatus(o.id,$event).subscribe({next:()=>load(),error:e=>msg=e.error})">@for (s of statuses; track s) { <option [value]="s">{{s}}</option> }</select></div> }
  }

  @if (tab=='users' && auth.user()?.role=='Admin') {
    @for (u of users(); track u.id) { <div>{{u.fullName}} ({{u.email}}) ·
      <select [ngModel]="u.role" (ngModelChange)="api.updateUser(u.id,{role:$event}).subscribe(()=>load())"><option>Customer</option><option>Manager</option><option>Admin</option></select></div> }
  }`
})
export class AdminComponent implements OnInit {
  api = inject(ShopApi); auth = inject(AuthService);
  tabs = [['dash', 'დაფა'], ['products', 'პროდუქტები'], ['cats', 'კატეგორიები'], ['camps', 'ფასდაკლებები'], ['orders', 'შეკვეთები'], ['users', 'მომხმარებლები']];
  tab = 'dash'; msg = '';
  statuses = ['Pending', 'Paid', 'Processing', 'Shipped', 'Delivered', 'Cancelled'];
  stats = signal<any>(null); notes = signal<any[]>([]); low = signal<any[]>([]); products = signal<any[]>([]); flat = signal<any[]>([]);
  camps = signal<any[]>([]); orders = signal<any[]>([]); users = signal<any[]>([]);
  editId: number | null = null; imgs = ''; specs = ''; p: any = this.blank();
  cn = ''; cp: number | null = null;
  c: any = { name: '', percent: 10, startsAt: '', endsAt: '', enabled: true }; cids = '';

  blank() { return { name: '', description: '', brand: '', sku: '', price: 0, categoryId: 0, stockQuantity: 0, minStockThreshold: 5, isActive: true }; }
  ngOnInit() { this.load(); }
  scale(s: any) { return Math.max(1, ...s.daily.map((d: any) => d.revenue)) / 300; }
  err = (e: any) => this.msg = typeof e.error === 'string' ? e.error : JSON.stringify(e.error);
  load() {
    this.msg = '';
    this.api.analytics().subscribe(this.stats.set); this.api.notifications().subscribe(this.notes.set); this.api.lowStock().subscribe(this.low.set);
    this.api.products({ pageSize: 100 }).subscribe(r => this.products.set(r.items));
    this.api.categories().subscribe(t => { const out: any[] = []; const walk = (n: any[], d: number) => n.forEach(c => { out.push({ id: c.id, name: c.name, label: '— '.repeat(d) + c.name }); walk(c.children, d + 1); }); walk(t, 0); this.flat.set(out); if (!this.p.categoryId && out[0]) this.p.categoryId = out[0].id; });
    this.api.campaigns().subscribe(this.camps.set); this.api.orders().subscribe(this.orders.set);
    if (this.auth.user()?.role === 'Admin') this.api.users().subscribe(this.users.set);
  }
  // პროდუქტები
  editProduct(x: any) { this.editId = x.id; this.p = { ...x }; this.imgs = x.images.join('\n'); this.specs = Object.entries(x.specifications).map(([k, v]) => `${k}=${v}`).join('\n'); this.tab = 'products'; }
  resetProduct() { this.editId = null; this.p = this.blank(); this.imgs = ''; this.specs = ''; this.p.categoryId = this.flat()[0]?.id ?? 0; }
  saveProduct() {
    const body = { ...this.p, images: this.imgs.split('\n').map(s => s.trim()).filter(Boolean),
      specifications: Object.fromEntries(this.specs.split('\n').filter(l => l.includes('=')).map(l => [l.split('=')[0].trim(), l.substring(l.indexOf('=') + 1).trim()])) };
    this.api.saveProduct(body, this.editId ?? undefined).subscribe({ next: () => { this.resetProduct(); this.load(); this.msg = 'შენახულია'; }, error: this.err });
  }
  delProduct(id: number) { if (confirm('დამალვა/წაშლა?')) this.api.deleteProduct(id).subscribe({ next: () => this.load(), error: this.err }); }
  // კატეგორიები
  addCat() { this.api.addCategory({ name: this.cn, parentId: this.cp }).subscribe({ next: () => { this.cn = ''; this.load(); }, error: this.err }); }
  renameCat(c: any) { const n = prompt('ახალი სახელი', c.name); if (n) this.api.updateCategory(c.id, { name: n, parentId: null }).subscribe({ next: () => this.load(), error: this.err }); }
  delCat(id: number) { this.api.deleteCategory(id).subscribe({ next: () => this.load(), error: this.err }); }
  // კამპანიები
  saveCamp() {
    const body = { ...this.c, startsAt: new Date(this.c.startsAt).toISOString(), endsAt: new Date(this.c.endsAt).toISOString(),
      productIds: this.cids.split(',').map(s => +s.trim()).filter(Boolean) };
    this.api.saveCampaign(body).subscribe({ next: () => { this.load(); this.msg = 'კამპანია შეიქმნა'; }, error: this.err });
  }
  delCamp(id: number) { this.api.deleteCampaign(id).subscribe(() => this.load()); }
}
