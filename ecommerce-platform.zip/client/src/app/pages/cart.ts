import { Component, inject, OnInit, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ShopApi } from '../core';

@Component({
  standalone: true, imports: [FormsModule],
  template: `
  <h2>კალათა</h2>
  @for (i of cart().items; track i.id) {
    <div style="display:flex;gap:12px;align-items:center;margin:6px 0">
      <span style="flex:1">{{i.name}}</span><span>{{i.unitPrice}} ₾</span>
      <input type="number" min="1" [max]="i.stock" [ngModel]="i.quantity" (change)="qty(i, $any($event.target).valueAsNumber)" style="width:60px">
      <b>{{i.lineTotal}} ₾</b><button (click)="remove(i)">✕</button>
    </div>
  } @empty { <p>კალათა ცარიელია</p> }
  @if (cart().items.length) {
    <h3>მიწოდება და გადახდა</h3>
    <select [(ngModel)]="dm" (change)="load()">@for (d of methods(); track d.id) { <option [ngValue]="d.id">{{d.name}} — {{d.price}} ₾</option> }</select>
    <select [(ngModel)]="addr">@for (a of addresses(); track a.id) { <option [ngValue]="a.id">{{a.city}}, {{a.street}}</option> }</select>
    <select [(ngModel)]="payment"><option value="card">ბარათი</option><option value="cod">ნაღდი ანგარიშსწორება</option></select>
    <details><summary>+ ახალი მისამართი</summary>
      <input [(ngModel)]="na.city" placeholder="ქალაქი"><input [(ngModel)]="na.street" placeholder="ქუჩა"><button (click)="saveAddr()">შენახვა</button></details>
    <p>ჯამი: {{cart().totals.subtotal}} ₾ · მიწოდება: {{cart().totals.shipping}} ₾ · გადასახადი (დღგ): {{cart().totals.tax}} ₾</p>
    <h3>სულ: {{cart().totals.total}} ₾</h3>
    <button (click)="order()">შეკვეთის გაფორმება</button>
  }
  @if (msg) { <p>{{msg}}</p> }
  <h2>შეკვეთების ისტორია</h2>
  @for (o of orders(); track o.id) { <p>#{{o.id}} · {{o.createdAt}} · <b>{{o.status}}</b> · {{o.totals.total}} ₾</p> }`
})
export class CartComponent implements OnInit {
  api = inject(ShopApi);
  cart = signal<any>({ items: [], totals: {} }); methods = signal<any[]>([]); addresses = signal<any[]>([]); orders = signal<any[]>([]);
  dm = 1; addr: number | null = null; payment = 'card'; msg = ''; na: any = { label: 'Home', city: '', street: '', isDefault: true };
  ngOnInit() {
    this.api.delivery().subscribe(m => { this.methods.set(m); this.dm = m[0]?.id; this.load(); });
    this.api.addresses().subscribe(a => { this.addresses.set(a); this.addr = a.find(x => x.isDefault)?.id ?? a[0]?.id ?? null; });
    this.api.orders().subscribe(this.orders.set);
  }
  load() { this.api.cart(this.dm).subscribe(this.cart.set); }
  qty(i: any, q: number) { this.api.setQty(i.id, q).subscribe({ next: () => this.load(), error: e => { this.msg = e.error; this.load(); } }); }
  remove(i: any) { this.api.removeItem(i.id).subscribe(() => this.load()); }
  saveAddr() { this.api.addAddress(this.na).subscribe(a => { this.addresses.update(l => [...l, a]); this.addr = a.id; }); }
  order() {
    if (!this.addr) { this.msg = 'აირჩიეთ მისამართი'; return; }
    this.api.placeOrder({ deliveryMethodId: this.dm, addressId: this.addr, paymentMethod: this.payment }).subscribe({
      next: o => { this.msg = `შეკვეთა #${o.id} გაფორმდა`; this.load(); this.api.orders().subscribe(this.orders.set); }, error: e => this.msg = typeof e.error === 'string' ? e.error : 'შეცდომა' });
  }
}
