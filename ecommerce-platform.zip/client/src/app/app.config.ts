import { ApplicationConfig } from '@angular/core';
import { provideRouter, Routes } from '@angular/router';
import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { authGuard, authInterceptor, staffGuard } from './core';

export const routes: Routes = [
  { path: '', loadComponent: () => import('./pages/catalog').then(m => m.CatalogComponent) },
  { path: 'login', loadComponent: () => import('./pages/login').then(m => m.LoginComponent) },
  { path: 'product/:id', loadComponent: () => import('./pages/product').then(m => m.ProductComponent) },
  { path: 'account', canActivate: [authGuard], loadComponent: () => import('./pages/account').then(m => m.AccountComponent) },
  { path: 'cart', canActivate: [authGuard], loadComponent: () => import('./pages/cart').then(m => m.CartComponent) },
  { path: 'admin', canActivate: [staffGuard], loadComponent: () => import('./pages/admin').then(m => m.AdminComponent) },
  { path: '**', redirectTo: '' }
];
export const appConfig: ApplicationConfig = { providers: [provideRouter(routes), provideHttpClient(withInterceptors([authInterceptor]))] };
