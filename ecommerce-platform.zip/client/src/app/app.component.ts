import { Component, inject } from '@angular/core';
import { RouterLink, RouterOutlet } from '@angular/router';
import { AuthService } from './core';

@Component({
  selector: 'app-root', standalone: true, imports: [RouterOutlet, RouterLink],
  template: `
  <nav style="display:flex;gap:16px;padding:12px 24px;background:#1f2937;color:#fff">
    <a routerLink="/" style="color:#fff"><b>🛒 Shop</b></a>
    <a routerLink="/cart" style="color:#fff">კალათა</a>
    @if (auth.user()) { <a routerLink="/account" style="color:#fff">ჩემი ანგარიში</a> }
    @if (auth.isStaff) { <a routerLink="/admin" style="color:#fff">ადმინ-პანელი</a> }
    <span style="margin-left:auto">
      @if (auth.user(); as u) { {{u.fullName}} · <a href="#" (click)="auth.logout();$event.preventDefault()" style="color:#fff">გასვლა</a> }
      @else { <a routerLink="/login" style="color:#fff">შესვლა</a> }
    </span>
  </nav>
  <main style="max-width:1100px;margin:24px auto;padding:0 16px"><router-outlet/></main>`
})
export class AppComponent { auth = inject(AuthService); }
