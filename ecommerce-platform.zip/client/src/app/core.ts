import { Injectable, inject, signal } from '@angular/core';
import { HttpClient, HttpInterceptorFn, HttpParams } from '@angular/common/http';
import { CanActivateFn, Router } from '@angular/router';

export const API = 'https://localhost:7001/api'; // შეცვალეთ თქვენი API პორტით

@Injectable({ providedIn: 'root' })
export class AuthService {
  private http = inject(HttpClient);
  user = signal<any>(JSON.parse(localStorage.getItem('user') ?? 'null'));
  get token() { return localStorage.getItem('token'); }
  get isStaff() { return ['Admin', 'Manager'].includes(this.user()?.role); }
  login(email: string, password: string) { return this.http.post<any>(`${API}/auth/login`, { email, password }); }
  register(d: any) { return this.http.post<any>(`${API}/auth/register`, d); }
  save(r: any) { localStorage.setItem('token', r.token); localStorage.setItem('user', JSON.stringify(r.user)); this.user.set(r.user); }
  logout() { localStorage.clear(); this.user.set(null); }
}

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const t = inject(AuthService).token;
  return next(t ? req.clone({ setHeaders: { Authorization: `Bearer ${t}` } }) : req);
};
export const authGuard: CanActivateFn = () => inject(AuthService).user() ? true : inject(Router).parseUrl('/login');
export const staffGuard: CanActivateFn = () => inject(AuthService).isStaff ? true : inject(Router).parseUrl('/');

@Injectable({ providedIn: 'root' })
export class ShopApi {
  private http = inject(HttpClient);
  products(f: any) { let p = new HttpParams(); Object.entries(f).forEach(([k, v]) => v !== null && v !== '' && v !== undefined && (p = p.set(k, String(v)))); return this.http.get<any>(`${API}/products`, { params: p }); }
  product(id: number) { return this.http.get<any>(`${API}/products/${id}`); }
  similar(id: number) { return this.http.get<any[]>(`${API}/products/${id}/similar`); }
  brands() { return this.http.get<string[]>(`${API}/products/brands`); }
  categories() { return this.http.get<any[]>(`${API}/categories`); }
  cart(dm?: number) { return this.http.get<any>(`${API}/cart`, { params: dm ? { deliveryMethodId: dm } : {} }); }
  addToCart(productId: number, quantity = 1) { return this.http.post(`${API}/cart/items`, { productId, quantity }); }
  setQty(id: number, quantity: number) { return this.http.put(`${API}/cart/items/${id}/quantity`, { quantity }); }
  removeItem(id: number) { return this.http.delete(`${API}/cart/items/${id}`); }
  delivery() { return this.http.get<any[]>(`${API}/delivery-methods`); }
  addresses() { return this.http.get<any[]>(`${API}/addresses`); }
  addAddress(a: any) { return this.http.post<any>(`${API}/addresses`, a); }
  placeOrder(o: any) { return this.http.post<any>(`${API}/orders`, o); }
  orders(status?: string) { return this.http.get<any[]>(`${API}/orders`, { params: status ? { status } : {} }); }
  setStatus(id: number, status: string) { return this.http.put(`${API}/orders/${id}/status`, { status }); }
  wishlistAdd(id: number) { return this.http.post(`${API}/wishlist/${id}`, {}); }
  recommendations() { return this.http.get<any[]>(`${API}/recommendations`); }
  analytics() { return this.http.get<any>(`${API}/admin/analytics`); }
  notifications() { return this.http.get<any[]>(`${API}/admin/notifications`); }
  lowStock() { return this.http.get<any[]>(`${API}/products/admin/low-stock`); }
  saveProduct(p: any, id?: number) { return id ? this.http.put(`${API}/products/${id}`, p) : this.http.post(`${API}/products`, p); }
  deleteProduct(id: number) { return this.http.delete(`${API}/products/${id}`); }
  // --- დამატებითი ---
  reviews(id: number) { return this.http.get<any[]>(`${API}/products/${id}/reviews`); }
  addReview(id: number, rating: number, comment: string) { return this.http.post(`${API}/products/${id}/reviews`, { rating, comment }); }
  wishlist() { return this.http.get<any[]>(`${API}/wishlist`); }
  wishlistRemove(id: number) { return this.http.delete(`${API}/wishlist/${id}`); }
  me() { return this.http.get<any>(`${API}/users/me`); }
  updateUser(id: number, d: any) { return this.http.put<any>(`${API}/users/${id}`, d); }
  users() { return this.http.get<any[]>(`${API}/users`); }
  updateAddress(id: number, a: any) { return this.http.put<any>(`${API}/addresses/${id}`, a); }
  deleteAddress(id: number) { return this.http.delete(`${API}/addresses/${id}`); }
  addCategory(c: any) { return this.http.post(`${API}/categories`, c); }
  updateCategory(id: number, c: any) { return this.http.put(`${API}/categories/${id}`, c); }
  deleteCategory(id: number) { return this.http.delete(`${API}/categories/${id}`); }
  campaigns() { return this.http.get<any[]>(`${API}/admin/campaigns`); }
  saveCampaign(c: any, id?: number) { return id ? this.http.put(`${API}/admin/campaigns/${id}`, c) : this.http.post(`${API}/admin/campaigns`, c); }
  deleteCampaign(id: number) { return this.http.delete(`${API}/admin/campaigns/${id}`); }
  readNote(id: number) { return this.http.put(`${API}/admin/notifications/${id}/read`, {}); }
}
