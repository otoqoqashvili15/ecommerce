# E-Commerce Platform (ASP.NET Core 8 + SQL Server + Angular)

## Backend
```
cd ECommerce.Api
dotnet restore
dotnet run          # Swagger: https://localhost:<port>/swagger
```
- appsettings.json -> ConnectionStrings:Default და Jwt:Key (შეცვალეთ!)
- პირველ გაშვებისას იქმნება ბაზა და ადმინი: admin@shop.ge / Admin#12345 (შეცვალეთ Seed-ში)
- როლები: Admin, Manager, Customer

## Frontend (Angular 17+)
```
cd client
npm install
npm start   # http://localhost:4200
```
core.ts-ში `API` მუდმივა დააყენეთ თქვენი backend-ის პორტზე.

## Production-ისთვის
- EnsureCreated -> EF Core migrations; Jwt:Key გადაიტანეთ user-secrets/env-ში
- FakePaymentGateway ჩაანაცვლეთ რეალური გადახდის პროვაიდერით (IPaymentGateway)
