using System.ComponentModel.DataAnnotations;
namespace ECommerce.Api.Dtos;

public record RegisterDto([Required, EmailAddress] string Email, [Required, MinLength(8)] string Password, [Required] string FullName, string? Phone);
public record LoginDto([Required] string Email, [Required] string Password);
public record UserDto(int Id, string Email, string FullName, string? Phone, string Role, DateTime CreatedAt);
public record AuthResponse(string Token, UserDto User);
public record UpdateUserDto(string? FullName, string? Phone, string? Role, string? NewPassword);

public record CategoryDto(int Id, string Name, int? ParentId, List<CategoryDto> Children);
public record CategorySaveDto([Required, MaxLength(150)] string Name, int? ParentId);

public class ProductQuery
{
    public string? Search { get; set; }
    public int? CategoryId { get; set; }
    public string? Brand { get; set; }
    public decimal? MinPrice { get; set; }
    public decimal? MaxPrice { get; set; }
    public bool? InStock { get; set; }
    public string? Sort { get; set; }
    public int Page { get; set; } = 1;
    public int PageSize { get; set; } = 12;
}
public record PagedResult<T>(List<T> Items, int Total, int Page, int PageSize);
public record ProductDto(int Id, string Name, string Description, string? Sku, string Brand, decimal Price, decimal FinalPrice,
    decimal DiscountPercent, int CategoryId, string CategoryName, int StockQuantity, Dictionary<string, string> Specifications,
    List<string> Images, double AvgRating, int ReviewCount);
public class ProductSaveDto
{
    [Required, MaxLength(250)] public string Name { get; set; } = "";
    public string Description { get; set; } = "";
    [MaxLength(60)] public string? Sku { get; set; }
    [MaxLength(100)] public string Brand { get; set; } = "";
    [Range(0, 10000000)] public decimal Price { get; set; }
    public int CategoryId { get; set; }
    [Range(0, int.MaxValue)] public int StockQuantity { get; set; }
    [Range(0, int.MaxValue)] public int MinStockThreshold { get; set; } = 5;
    public Dictionary<string, string> Specifications { get; set; } = new();
    public List<string> Images { get; set; } = new();
    public bool IsActive { get; set; } = true;
}
public record ReviewDto(int Id, int ProductId, string UserName, int Rating, string Comment, DateTime CreatedAt);
public record ReviewSaveDto([Range(1, 5)] int Rating, [MaxLength(2000)] string Comment);

public record CartAddDto(int ProductId, [Range(1, 1000)] int Quantity);
public record CartQtyDto([Range(1, 1000)] int Quantity);
public record CartItemDto(int Id, int ProductId, string Name, string? Image, decimal UnitPrice, int Quantity, decimal LineTotal, int Stock);
public record TotalsDto(decimal Subtotal, decimal Shipping, decimal Tax, decimal Total);
public record CartDto(List<CartItemDto> Items, TotalsDto Totals);

public record AddressDto(int Id, string Label, string City, string Street, string? PostalCode, bool IsDefault);
public record AddressSaveDto([Required] string Label, [Required] string City, [Required] string Street, string? PostalCode, bool IsDefault);

public record CreateOrderDto(int DeliveryMethodId, int AddressId, [Required] string PaymentMethod);
public record OrderItemDto(int ProductId, string ProductName, decimal UnitPrice, int Quantity);
public record OrderDto(int Id, int UserId, string Status, TotalsDto Totals, string DeliveryMethod, string ShippingAddress,
    string PaymentMethod, DateTime CreatedAt, List<OrderItemDto> Items);
public record StatusDto([Required] string Status);

public record CampaignDto(int Id, string Name, decimal Percent, DateTime StartsAt, DateTime EndsAt, bool Enabled, bool IsActive, List<int> ProductIds);
public record CampaignSaveDto([Required] string Name, [Range(1, 95)] decimal Percent, DateTime StartsAt, DateTime EndsAt, bool Enabled, List<int> ProductIds);
