using ECommerce.Api.Data;
using ECommerce.Api.Dtos;
using ECommerce.Api.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace ECommerce.Api.Controllers;

[ApiController, Route("api/admin"), Authorize(Roles = Roles.Staff)]
public class AdminController(AppDbContext db) : ControllerBase
{
    // ---- გაყიდვების ანალიტიკა ----
    [HttpGet("analytics")]
    public async Task<object> Analytics([FromQuery] int days = 30)
    {
        var from = DateTime.UtcNow.Date.AddDays(-Math.Clamp(days, 1, 365));
        var valid = db.Orders.Where(o => o.Status != OrderStatus.Cancelled && o.CreatedAt >= from);
        var daily = await valid.GroupBy(o => o.CreatedAt.Date).Select(g => new { Date = g.Key, Orders = g.Count(), Revenue = g.Sum(o => o.Total) }).OrderBy(x => x.Date).ToListAsync();
        var top = await db.OrderItems.Where(i => i.Order.Status != OrderStatus.Cancelled && i.Order.CreatedAt >= from)
            .GroupBy(i => new { i.ProductId, i.ProductName }).Select(g => new { g.Key.ProductId, g.Key.ProductName, Units = g.Sum(i => i.Quantity), Revenue = g.Sum(i => i.Quantity * i.UnitPrice) })
            .OrderByDescending(x => x.Units).Take(10).ToListAsync();
        var byStatus = (await db.Orders.GroupBy(o => o.Status).Select(g => new { Status = g.Key, Count = g.Count() }).ToListAsync())
            .Select(x => new { Status = x.Status.ToString(), x.Count }).ToList();
        return new
        {
            Days = days, TotalOrders = await valid.CountAsync(), TotalRevenue = await valid.SumAsync(o => (decimal?)o.Total) ?? 0,
            Customers = await db.Users.CountAsync(u => u.Role == Roles.Customer), Daily = daily, TopProducts = top, OrdersByStatus = byStatus
        };
    }

    // ---- შეტყობინებები ----
    [HttpGet("notifications")]
    public async Task<List<Notification>> Notifications([FromQuery] bool unreadOnly = false) =>
        await db.Notifications.AsNoTracking().Where(n => !unreadOnly || !n.IsRead).OrderByDescending(n => n.CreatedAt).Take(100).ToListAsync();

    [HttpPut("notifications/{id}/read")]
    public async Task<IActionResult> Read(int id) { await db.Notifications.Where(n => n.Id == id).ExecuteUpdateAsync(s => s.SetProperty(n => n.IsRead, true)); return NoContent(); }

    // ---- მარკეტინგული კამპანიები / ფასდაკლებები ----
    static CampaignDto Map(Campaign c) => new(c.Id, c.Name, c.Percent, c.StartsAt, c.EndsAt, c.Enabled, c.IsActive, c.Products.Select(p => p.Id).ToList());

    [HttpGet("campaigns")]
    public async Task<List<CampaignDto>> Campaigns() => (await db.Campaigns.AsNoTracking().Include(c => c.Products).OrderByDescending(c => c.StartsAt).ToListAsync()).Select(Map).ToList();

    [HttpPost("campaigns")]
    public async Task<ActionResult<CampaignDto>> CreateCampaign(CampaignSaveDto d)
    {
        if (d.EndsAt <= d.StartsAt) return BadRequest("დასრულება უნდა იყოს დაწყების შემდეგ");
        var c = new Campaign(); await Apply(c, d); db.Campaigns.Add(c); await db.SaveChangesAsync(); return Map(c);
    }

    [HttpPut("campaigns/{id}")]
    public async Task<ActionResult<CampaignDto>> UpdateCampaign(int id, CampaignSaveDto d)
    {
        var c = await db.Campaigns.Include(x => x.Products).FirstOrDefaultAsync(x => x.Id == id); if (c == null) return NotFound();
        if (d.EndsAt <= d.StartsAt) return BadRequest("დასრულება უნდა იყოს დაწყების შემდეგ");
        await Apply(c, d); await db.SaveChangesAsync(); return Map(c);
    }

    [HttpDelete("campaigns/{id}")]
    public async Task<IActionResult> DeleteCampaign(int id) { await db.Campaigns.Where(c => c.Id == id).ExecuteDeleteAsync(); return NoContent(); }

    async Task Apply(Campaign c, CampaignSaveDto d)
    {
        c.Name = d.Name; c.Percent = d.Percent; c.StartsAt = d.StartsAt.ToUniversalTime(); c.EndsAt = d.EndsAt.ToUniversalTime(); c.Enabled = d.Enabled;
        c.Products = await db.Products.Where(p => d.ProductIds.Contains(p.Id)).ToListAsync();
        var now = DateTime.UtcNow; c.IsActive = c.Enabled && c.StartsAt <= now && c.EndsAt >= now;
    }
}
