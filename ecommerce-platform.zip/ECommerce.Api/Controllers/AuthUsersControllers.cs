using ECommerce.Api.Data;
using ECommerce.Api.Dtos;
using ECommerce.Api.Models;
using ECommerce.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace ECommerce.Api.Controllers;

[ApiController, Route("api/auth")]
public class AuthController(AppDbContext db, TokenService tokens) : ControllerBase
{
    static UserDto Map(User u) => new(u.Id, u.Email, u.FullName, u.Phone, u.Role, u.CreatedAt);

    [HttpPost("register")]
    public async Task<ActionResult<AuthResponse>> Register(RegisterDto d)
    {
        var email = d.Email.Trim().ToLower();
        if (await db.Users.AnyAsync(u => u.Email == email)) return Conflict("ელფოსტა უკვე რეგისტრირებულია");
        var u = new User { Email = email, FullName = d.FullName, Phone = d.Phone, PasswordHash = BCrypt.Net.BCrypt.HashPassword(d.Password) };
        db.Users.Add(u); await db.SaveChangesAsync();
        return new AuthResponse(tokens.Create(u), Map(u));
    }

    [HttpPost("login")]
    public async Task<ActionResult<AuthResponse>> Login(LoginDto d)
    {
        var u = await db.Users.FirstOrDefaultAsync(x => x.Email == d.Email.Trim().ToLower());
        if (u == null || !BCrypt.Net.BCrypt.Verify(d.Password, u.PasswordHash)) return Unauthorized("არასწორი ელფოსტა ან პაროლი");
        return new AuthResponse(tokens.Create(u), Map(u));
    }
}

[ApiController, Route("api/users"), Authorize]
public class UsersController(AppDbContext db) : ControllerBase
{
    static UserDto Map(User u) => new(u.Id, u.Email, u.FullName, u.Phone, u.Role, u.CreatedAt);

    [HttpGet, Authorize(Roles = Roles.Admin)]
    public async Task<List<UserDto>> List() => (await db.Users.AsNoTracking().OrderBy(u => u.Id).ToListAsync()).Select(Map).ToList();

    [HttpGet("me")]
    public async Task<ActionResult<UserDto>> Me() => Map(await db.Users.FindAsync(User.Id()) ?? throw new InvalidOperationException());

    [HttpPut("{id}")]
    public async Task<ActionResult<UserDto>> Update(int id, UpdateUserDto d)
    {
        var admin = User.IsInRole(Roles.Admin);
        if (id != User.Id() && !admin) return Forbid();
        var u = await db.Users.FindAsync(id); if (u == null) return NotFound();
        if (!string.IsNullOrWhiteSpace(d.FullName)) u.FullName = d.FullName;
        if (d.Phone != null) u.Phone = d.Phone;
        if (!string.IsNullOrEmpty(d.NewPassword))
        {
            if (d.NewPassword.Length < 8) return BadRequest("პაროლი მინიმუმ 8 სიმბოლო");
            u.PasswordHash = BCrypt.Net.BCrypt.HashPassword(d.NewPassword);
        }
        if (d.Role != null)
        {
            if (!admin) return Forbid();
            if (d.Role is not (Roles.Admin or Roles.Manager or Roles.Customer)) return BadRequest("არასწორი როლი");
            u.Role = d.Role;
        }
        await db.SaveChangesAsync(); return Map(u);
    }

    [HttpGet("{id}/orders")]
    public async Task<ActionResult<List<OrderDto>>> Orders(int id)
    {
        if (id != User.Id() && !User.IsStaff()) return Forbid();
        var list = await db.Orders.AsNoTracking().Include(o => o.Items).Include(o => o.DeliveryMethod)
            .Where(o => o.UserId == id).OrderByDescending(o => o.CreatedAt).ToListAsync();
        return list.Select(OrdersController.Map).ToList();
    }
}

[ApiController, Route("api/addresses"), Authorize]
public class AddressesController(AppDbContext db) : ControllerBase
{
    static AddressDto Map(Address a) => new(a.Id, a.Label, a.City, a.Street, a.PostalCode, a.IsDefault);
    [HttpGet] public async Task<List<AddressDto>> List() =>
        (await db.Addresses.AsNoTracking().Where(a => a.UserId == User.Id()).ToListAsync()).Select(Map).ToList();

    [HttpPost] public async Task<AddressDto> Create(AddressSaveDto d)
    {
        var a = new Address { UserId = User.Id() }; Apply(a, d);
        if (d.IsDefault) await ClearDefault(a.UserId);
        db.Addresses.Add(a); await db.SaveChangesAsync(); return Map(a);
    }
    [HttpPut("{id}")] public async Task<ActionResult<AddressDto>> Update(int id, AddressSaveDto d)
    {
        var a = await db.Addresses.FirstOrDefaultAsync(x => x.Id == id && x.UserId == User.Id()); if (a == null) return NotFound();
        if (d.IsDefault) await ClearDefault(a.UserId);
        Apply(a, d); await db.SaveChangesAsync(); return Map(a);
    }
    [HttpDelete("{id}")] public async Task<IActionResult> Delete(int id)
    {
        var a = await db.Addresses.FirstOrDefaultAsync(x => x.Id == id && x.UserId == User.Id()); if (a == null) return NotFound();
        db.Addresses.Remove(a); await db.SaveChangesAsync(); return NoContent();
    }
    static void Apply(Address a, AddressSaveDto d) { a.Label = d.Label; a.City = d.City; a.Street = d.Street; a.PostalCode = d.PostalCode; a.IsDefault = d.IsDefault; }
    async Task ClearDefault(int uid) => await db.Addresses.Where(x => x.UserId == uid && x.IsDefault).ExecuteUpdateAsync(s => s.SetProperty(x => x.IsDefault, false));
}
