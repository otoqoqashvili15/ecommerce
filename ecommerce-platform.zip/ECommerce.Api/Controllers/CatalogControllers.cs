using System.Text.Json;
using ECommerce.Api.Data;
using ECommerce.Api.Dtos;
using ECommerce.Api.Models;
using ECommerce.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace ECommerce.Api.Controllers;

[ApiController, Route("api/categories")]
public class CategoriesController(AppDbContext db) : ControllerBase
{
    [HttpGet] public async Task<List<CategoryDto>> Tree()
    {
        var all = await db.Categories.AsNoTracking().OrderBy(c => c.Name).ToListAsync();
        CategoryDto Build(Category c) => new(c.Id, c.Name, c.ParentId, all.Where(x => x.ParentId == c.Id).Select(Build).ToList());
        return all.Where(c => c.ParentId == null).Select(Build).ToList();
    }

    [HttpPost, Authorize(Roles = Roles.Staff)]
    public async Task<ActionResult<CategoryDto>> Create(CategorySaveDto d)
    {
        if (d.ParentId != null && !await db.Categories.AnyAsync(c => c.Id == d.ParentId)) return BadRequest("მშობელი კატეგორია ვერ მოიძებნა");
        var c = new Category { Name = d.Name, ParentId = d.ParentId }; db.Categories.Add(c); await db.SaveChangesAsync();
        return new CategoryDto(c.Id, c.Name, c.ParentId, new());
    }

    [HttpPut("{id}"), Authorize(Roles = Roles.Staff)]
    public async Task<IActionResult> Update(int id, CategorySaveDto d)
    {
        var c = await db.Categories.FindAsync(id); if (c == null) return NotFound();
        // ციკლის თავიდან აცილება
        for (var p = d.ParentId; p != null; p = (await db.Categories.FindAsync(p))?.ParentId)
            if (p == id) return BadRequest("კატეგორია ვერ იქნება საკუთარი შთამომავლის შვილი");
        c.Name = d.Name; c.ParentId = d.ParentId; await db.SaveChangesAsync(); return NoContent();
    }

    [HttpDelete("{id}"), Authorize(Roles = Roles.Staff)]
    public async Task<IActionResult> Delete(int id)
    {
        if (await db.Categories.AnyAsync(c => c.ParentId == id) || await db.Products.AnyAsync(p => p.CategoryId == id))
            return Conflict("კატეგორია შეიცავს ქვეკატეგორიებს ან პროდუქტებს");
        var c = await db.Categories.FindAsync(id); if (c == null) return NotFound();
        db.Categories.Remove(c); await db.SaveChangesAsync(); return NoContent();
    }
}

[ApiController, Route("api/products")]
public class ProductsController(AppDbContext db, CatalogService catalog) : ControllerBase
{
    IQueryable<Product> Base() => db.Products.AsNoTracking().Include(p => p.Images).Include(p => p.Category);

    [HttpGet]
    public async Task<PagedResult<ProductDto>> List([FromQuery] ProductQuery q)
    {
        q.Page = Math.Max(1, q.Page); q.PageSize = Math.Clamp(q.PageSize, 1, 100);
        var query = Base().Where(p => p.IsActive);
        if (!string.IsNullOrWhiteSpace(q.Search)) query = query.Where(p => p.Name.Contains(q.Search) || p.Description.Contains(q.Search) || p.Brand.Contains(q.Search));
        if (q.CategoryId is int cid) { var ids = await catalog.CategoryWithDescendants(cid); query = query.Where(p => ids.Contains(p.CategoryId)); }
        if (!string.IsNullOrWhiteSpace(q.Brand)) query = query.Where(p => p.Brand == q.Brand);
        if (q.MinPrice != null) query = query.Where(p => p.Price >= q.MinPrice);
        if (q.MaxPrice != null) query = query.Where(p => p.Price <= q.MaxPrice);
        if (q.InStock == true) query = query.Where(p => p.StockQuantity > 0);
        query = q.Sort switch
        {
            "price_asc" => query.OrderBy(p => p.Price), "price_desc" => query.OrderByDescending(p => p.Price),
            "newest" => query.OrderByDescending(p => p.CreatedAt), _ => query.OrderBy(p => p.Name)
        };
        var total = await query.CountAsync();
        var items = await query.Skip((q.Page - 1) * q.PageSize).Take(q.PageSize).ToListAsync();
        return new(await catalog.ToDtos(items), total, q.Page, q.PageSize);
    }

    [HttpGet("brands")] public async Task<List<string>> Brands() =>
        await db.Products.Where(p => p.IsActive && p.Brand != "").Select(p => p.Brand).Distinct().OrderBy(b => b).ToListAsync();

    [HttpGet("{id}")]
    public async Task<ActionResult<ProductDto>> Get(int id)
    {
        var p = await Base().FirstOrDefaultAsync(x => x.Id == id && x.IsActive); if (p == null) return NotFound();
        return (await catalog.ToDtos(new() { p }))[0];
    }

    [HttpGet("{id}/similar")]
    public async Task<ActionResult<List<ProductDto>>> Similar(int id)
    {
        var p = await db.Products.AsNoTracking().FirstOrDefaultAsync(x => x.Id == id); if (p == null) return NotFound();
        var list = await Base().Where(x => x.IsActive && x.Id != id && (x.CategoryId == p.CategoryId || x.Brand == p.Brand))
            .OrderBy(x => x.CategoryId == p.CategoryId ? 0 : 1).ThenByDescending(x => x.CreatedAt).Take(8).ToListAsync();
        return await catalog.ToDtos(list);
    }

    [HttpPost, Authorize(Roles = Roles.Staff)]
    public async Task<ActionResult<ProductDto>> Create(ProductSaveDto d)
    {
        if (!await db.Categories.AnyAsync(c => c.Id == d.CategoryId)) return BadRequest("კატეგორია ვერ მოიძებნა");
        var p = new Product(); Apply(p, d); catalog.NotifyIfLow(p);
        db.Products.Add(p); await db.SaveChangesAsync();
        return CreatedAtAction(nameof(Get), new { id = p.Id }, (await catalog.ToDtos(new() { await Base().FirstAsync(x => x.Id == p.Id) }))[0]);
    }

    [HttpPut("{id}"), Authorize(Roles = Roles.Staff)]
    public async Task<ActionResult<ProductDto>> Update(int id, ProductSaveDto d)
    {
        var p = await db.Products.Include(x => x.Images).FirstOrDefaultAsync(x => x.Id == id); if (p == null) return NotFound();
        if (!await db.Categories.AnyAsync(c => c.Id == d.CategoryId)) return BadRequest("კატეგორია ვერ მოიძებნა");
        var wasLow = p.StockQuantity <= p.MinStockThreshold;
        db.ProductImages.RemoveRange(p.Images); p.Images.Clear();
        Apply(p, d); if (!wasLow) catalog.NotifyIfLow(p);
        try { await db.SaveChangesAsync(); } catch (DbUpdateConcurrencyException) { return Conflict("პროდუქტი სხვამ შეცვალა, განაახლეთ გვერდი"); }
        return (await catalog.ToDtos(new() { await Base().FirstAsync(x => x.Id == id) }))[0];
    }

    [HttpDelete("{id}"), Authorize(Roles = Roles.Staff)]
    public async Task<IActionResult> Delete(int id)
    {
        var p = await db.Products.FindAsync(id); if (p == null) return NotFound();
        p.IsActive = false;      // soft-delete: შეკვეთების ისტორია უცვლელი რჩება
        await db.SaveChangesAsync(); return NoContent();
    }

    // ადმინისთვის: ყველა პროდუქტი (მათ შორის დამალული) + დაბალი მარაგი
    [HttpGet("admin/low-stock"), Authorize(Roles = Roles.Staff)]
    public async Task<List<ProductDto>> LowStock() =>
        await catalog.ToDtos(await Base().Where(p => p.IsActive && p.StockQuantity <= p.MinStockThreshold).ToListAsync());

    static void Apply(Product p, ProductSaveDto d)
    {
        p.Name = d.Name; p.Description = d.Description; p.Sku = string.IsNullOrWhiteSpace(d.Sku) ? null : d.Sku; p.Brand = d.Brand;
        p.Price = d.Price; p.CategoryId = d.CategoryId; p.StockQuantity = d.StockQuantity; p.MinStockThreshold = d.MinStockThreshold;
        p.IsActive = d.IsActive; p.SpecificationsJson = JsonSerializer.Serialize(d.Specifications);
        p.Images = d.Images.Select((u, i) => new ProductImage { Url = u, SortOrder = i }).ToList();
    }

    // ---- შეფასებები ----
    [HttpGet("{id}/reviews")]
    public async Task<List<ReviewDto>> Reviews(int id) =>
        await db.Reviews.AsNoTracking().Where(r => r.ProductId == id).OrderByDescending(r => r.CreatedAt)
            .Select(r => new ReviewDto(r.Id, r.ProductId, r.User.FullName, r.Rating, r.Comment, r.CreatedAt)).ToListAsync();

    [HttpPost("{id}/reviews"), Authorize]
    public async Task<IActionResult> AddReview(int id, ReviewSaveDto d)
    {
        var uid = User.Id();
        if (!await db.Products.AnyAsync(p => p.Id == id)) return NotFound();
        // მხოლოდ იყიდა პროდუქტი — შეუძლია შეაფასოს
        var bought = await db.OrderItems.AnyAsync(i => i.ProductId == id && i.Order.UserId == uid && i.Order.Status != OrderStatus.Cancelled);
        if (!bought) return BadRequest("შეფასება შეუძლია მხოლოდ მყიდველს");
        var r = await db.Reviews.FirstOrDefaultAsync(x => x.ProductId == id && x.UserId == uid);
        if (r == null) db.Reviews.Add(r = new Review { ProductId = id, UserId = uid });
        r.Rating = d.Rating; r.Comment = d.Comment; r.CreatedAt = DateTime.UtcNow;
        await db.SaveChangesAsync(); return NoContent();
    }
}

[ApiController, Route("api/wishlist"), Authorize]
public class WishlistController(AppDbContext db, CatalogService catalog) : ControllerBase
{
    [HttpGet] public async Task<List<ProductDto>> List() =>
        await catalog.ToDtos(await db.Products.AsNoTracking().Include(p => p.Images).Include(p => p.Category)
            .Where(p => db.Wishlist.Any(w => w.UserId == User.Id() && w.ProductId == p.Id)).ToListAsync());

    [HttpPost("{productId}")] public async Task<IActionResult> Add(int productId)
    {
        if (!await db.Products.AnyAsync(p => p.Id == productId)) return NotFound();
        if (!await db.Wishlist.AnyAsync(w => w.UserId == User.Id() && w.ProductId == productId))
        { db.Wishlist.Add(new WishlistItem { UserId = User.Id(), ProductId = productId }); await db.SaveChangesAsync(); }
        return NoContent();
    }
    [HttpDelete("{productId}")] public async Task<IActionResult> Remove(int productId)
    {
        await db.Wishlist.Where(w => w.UserId == User.Id() && w.ProductId == productId).ExecuteDeleteAsync(); return NoContent();
    }
}

[ApiController, Route("api/recommendations"), Authorize]
public class RecommendationsController(AppDbContext db, CatalogService catalog) : ControllerBase
{
    /// პერსონალიზებული რეკომენდაცია: ნაყიდი/სურვილების სიის კატეგორიები და ბრენდები
    [HttpGet] public async Task<List<ProductDto>> Get()
    {
        var uid = User.Id();
        var bought = await db.OrderItems.Where(i => i.Order.UserId == uid).Select(i => i.Product).ToListAsync();
        var wished = await db.Wishlist.Where(w => w.UserId == uid).Select(w => w.Product).ToListAsync();
        var seen = bought.Concat(wished).ToList();
        var cats = seen.Select(p => p.CategoryId).Distinct().ToList(); var brands = seen.Select(p => p.Brand).Distinct().ToList();
        var seenIds = seen.Select(p => p.Id).ToList();
        var q = db.Products.AsNoTracking().Include(p => p.Images).Include(p => p.Category).Where(p => p.IsActive && p.StockQuantity > 0 && !seenIds.Contains(p.Id));
        var list = seen.Count == 0
            ? await q.OrderByDescending(p => p.CreatedAt).Take(8).ToListAsync()
            : await q.Where(p => cats.Contains(p.CategoryId) || brands.Contains(p.Brand)).OrderByDescending(p => cats.Contains(p.CategoryId)).Take(8).ToListAsync();
        return await catalog.ToDtos(list);
    }
}
