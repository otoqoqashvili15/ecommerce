using ECommerce.Api.Data;
using ECommerce.Api.Dtos;
using ECommerce.Api.Models;
using ECommerce.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
namespace ECommerce.Api.Controllers;

[ApiController, Route("api/cart"), Authorize]
public class CartController(AppDbContext db, CatalogService catalog) : ControllerBase
{
    [HttpGet]
    public async Task<CartDto> Get([FromQuery] int? deliveryMethodId)
    {
        var uid = User.Id();
        var items = await db.CartItems.AsNoTracking().Include(c => c.Product).ThenInclude(p => p.Images).Where(c => c.UserId == uid).ToListAsync();
        var disc = await catalog.DiscountPercents(items.Select(i => i.ProductId));
        var dtos = items.Select(i =>
        {
            disc.TryGetValue(i.ProductId, out var pct); var unit = CatalogService.Final(i.Product.Price, pct);
            return new CartItemDto(i.Id, i.ProductId, i.Product.Name, i.Product.Images.OrderBy(x => x.SortOrder).Select(x => x.Url).FirstOrDefault(),
                unit, i.Quantity, unit * i.Quantity, i.Product.StockQuantity);
        }).ToList();
        var ship = deliveryMethodId == null ? 0 : (await db.DeliveryMethods.FindAsync(deliveryMethodId))?.Price ?? 0;
        return new CartDto(dtos, catalog.Totals(dtos.Sum(d => d.LineTotal), ship));
    }

    [HttpPost("items")]
    public async Task<IActionResult> Add(CartAddDto d)
    {
        var uid = User.Id();
        var p = await db.Products.FindAsync(d.ProductId); if (p == null || !p.IsActive) return NotFound("პროდუქტი ვერ მოიძებნა");
        var item = await db.CartItems.FirstOrDefaultAsync(c => c.UserId == uid && c.ProductId == d.ProductId);
        var newQty = (item?.Quantity ?? 0) + d.Quantity;
        if (newQty > p.StockQuantity) return Conflict($"მარაგში მხოლოდ {p.StockQuantity} ერთეულია");
        if (item == null) db.CartItems.Add(new CartItem { UserId = uid, ProductId = d.ProductId, Quantity = newQty }); else item.Quantity = newQty;
        await db.SaveChangesAsync(); return NoContent();
    }

    [HttpPut("items/{id}/quantity")]
    public async Task<IActionResult> SetQty(int id, CartQtyDto d)
    {
        var item = await db.CartItems.Include(c => c.Product).FirstOrDefaultAsync(c => c.Id == id && c.UserId == User.Id()); if (item == null) return NotFound();
        if (d.Quantity > item.Product.StockQuantity) return Conflict($"მარაგში მხოლოდ {item.Product.StockQuantity} ერთეულია");
        item.Quantity = d.Quantity; await db.SaveChangesAsync(); return NoContent();
    }

    [HttpDelete("items/{id}")]
    public async Task<IActionResult> Remove(int id)
    {
        var n = await db.CartItems.Where(c => c.Id == id && c.UserId == User.Id()).ExecuteDeleteAsync();
        return n == 0 ? NotFound() : NoContent();
    }
}

[ApiController, Route("api/delivery-methods")]
public class DeliveryController(AppDbContext db) : ControllerBase
{
    [HttpGet] public async Task<List<DeliveryMethod>> List() => await db.DeliveryMethods.AsNoTracking().ToListAsync();
}

[ApiController, Route("api/orders"), Authorize]
public class OrdersController(AppDbContext db, CatalogService catalog, IPaymentGateway pay) : ControllerBase
{
    public static OrderDto Map(Order o) => new(o.Id, o.UserId, o.Status.ToString(), new(o.Subtotal, o.ShippingCost, o.Tax, o.Total),
        o.DeliveryMethod?.Name ?? "", o.ShippingAddress, o.PaymentMethod, o.CreatedAt,
        o.Items.Select(i => new OrderItemDto(i.ProductId, i.ProductName, i.UnitPrice, i.Quantity)).ToList());

    IQueryable<Order> Q() => db.Orders.Include(o => o.Items).Include(o => o.DeliveryMethod);

    [HttpGet]
    public async Task<List<OrderDto>> List([FromQuery] string? status)
    {
        var q = Q().AsNoTracking();
        if (!User.IsStaff()) q = q.Where(o => o.UserId == User.Id());
        if (Enum.TryParse<OrderStatus>(status, true, out var st)) q = q.Where(o => o.Status == st);
        return (await q.OrderByDescending(o => o.CreatedAt).ToListAsync()).Select(Map).ToList();
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<OrderDto>> Get(int id)
    {
        var o = await Q().AsNoTracking().FirstOrDefaultAsync(x => x.Id == id); if (o == null) return NotFound();
        if (o.UserId != User.Id() && !User.IsStaff()) return Forbid();
        return Map(o);
    }

    [HttpPost]
    public async Task<ActionResult<OrderDto>> Create(CreateOrderDto d)
    {
        var uid = User.Id();
        var cart = await db.CartItems.Include(c => c.Product).Where(c => c.UserId == uid).ToListAsync();
        if (cart.Count == 0) return BadRequest("კალათა ცარიელია");
        var dm = await db.DeliveryMethods.FindAsync(d.DeliveryMethodId); if (dm == null) return BadRequest("მიწოდების მეთოდი არასწორია");
        var a = await db.Addresses.FirstOrDefaultAsync(x => x.Id == d.AddressId && x.UserId == uid); if (a == null) return BadRequest("მისამართი ვერ მოიძებნა");
        foreach (var c in cart)
            if (!c.Product.IsActive || c.Product.StockQuantity < c.Quantity) return Conflict($"\"{c.Product.Name}\" — მარაგი არასაკმარისია");

        var disc = await catalog.DiscountPercents(cart.Select(c => c.ProductId));
        await using var tx = await db.Database.BeginTransactionAsync();
        var order = new Order
        {
            UserId = uid, DeliveryMethodId = dm.Id, PaymentMethod = d.PaymentMethod,
            ShippingAddress = $"{a.City}, {a.Street} {a.PostalCode}".Trim()
        };
        foreach (var c in cart)
        {
            disc.TryGetValue(c.ProductId, out var pct);
            order.Items.Add(new OrderItem { ProductId = c.ProductId, ProductName = c.Product.Name, UnitPrice = CatalogService.Final(c.Product.Price, pct), Quantity = c.Quantity });
            c.Product.StockQuantity -= c.Quantity; catalog.NotifyIfLow(c.Product);
        }
        var t = catalog.Totals(order.Items.Sum(i => i.UnitPrice * i.Quantity), dm.Price);
        order.Subtotal = t.Subtotal; order.ShippingCost = t.Shipping; order.Tax = t.Tax; order.Total = t.Total;
        var (ok, reference) = await pay.ChargeAsync(order.Total, d.PaymentMethod);
        if (!ok && d.PaymentMethod.ToLower() != "cod") return StatusCode(402, "გადახდა ვერ განხორციელდა");
        if (ok) { order.Status = OrderStatus.Paid; order.PaymentReference = reference; }
        db.Orders.Add(order); db.CartItems.RemoveRange(cart);
        try { await db.SaveChangesAsync(); await tx.CommitAsync(); }
        catch (DbUpdateConcurrencyException) { return Conflict("მარაგი შეიცვალა, სცადეთ თავიდან"); }
        order.DeliveryMethod = dm; return CreatedAtAction(nameof(Get), new { id = order.Id }, Map(order));
    }

    [HttpPut("{id}/status"), Authorize(Roles = Roles.Staff)]
    public async Task<IActionResult> SetStatus(int id, StatusDto d)
    {
        if (!Enum.TryParse<OrderStatus>(d.Status, true, out var st)) return BadRequest("არასწორი სტატუსი");
        var o = await db.Orders.Include(x => x.Items).ThenInclude(i => i.Product).FirstOrDefaultAsync(x => x.Id == id); if (o == null) return NotFound();
        if (o.Status == OrderStatus.Cancelled || o.Status == OrderStatus.Delivered) return Conflict("დასრულებული შეკვეთის სტატუსი ვერ შეიცვლება");
        if (st == OrderStatus.Cancelled) foreach (var i in o.Items) i.Product.StockQuantity += i.Quantity;   // მარაგის დაბრუნება
        o.Status = st; await db.SaveChangesAsync(); return NoContent();
    }
}
