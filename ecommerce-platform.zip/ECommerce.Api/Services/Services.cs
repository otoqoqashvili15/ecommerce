using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Text.Json;
using ECommerce.Api.Data;
using ECommerce.Api.Dtos;
using ECommerce.Api.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
namespace ECommerce.Api.Services;

public static class UserExt
{
    public static int Id(this ClaimsPrincipal u) => int.Parse(u.FindFirstValue(ClaimTypes.NameIdentifier)!);
    public static bool IsStaff(this ClaimsPrincipal u) => u.IsInRole(Roles.Admin) || u.IsInRole(Roles.Manager);
}

public class TokenService(IConfiguration cfg)
{
    public string Create(User u)
    {
        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(cfg["Jwt:Key"]!));
        var claims = new[]
        {
            new Claim(ClaimTypes.NameIdentifier, u.Id.ToString()), new Claim(ClaimTypes.Email, u.Email),
            new Claim(ClaimTypes.Name, u.FullName), new Claim(ClaimTypes.Role, u.Role)
        };
        var t = new JwtSecurityToken(cfg["Jwt:Issuer"], cfg["Jwt:Audience"], claims,
            expires: DateTime.UtcNow.AddHours(double.Parse(cfg["Jwt:ExpiresHours"] ?? "8")),
            signingCredentials: new SigningCredentials(key, SecurityAlgorithms.HmacSha256));
        return new JwtSecurityTokenHandler().WriteToken(t);
    }
}

public interface IPaymentGateway { Task<(bool Ok, string Reference)> ChargeAsync(decimal amount, string method); }
/// დროებითი იმპლემენტაცია — ჩაანაცვლეთ რეალური გადახდის პროვაიდერით (BOG, TBC, Stripe...)
public class FakePaymentGateway : IPaymentGateway
{
    public Task<(bool, string)> ChargeAsync(decimal amount, string method) =>
        Task.FromResult((method.ToLower() != "cod", method.ToLower() == "cod" ? "" : "PAY-" + Guid.NewGuid().ToString("N")[..12]));
}

public class CatalogService(AppDbContext db, IConfiguration cfg)
{
    public decimal TaxRate => decimal.Parse(cfg["Shop:TaxRate"] ?? "0.18", System.Globalization.CultureInfo.InvariantCulture);
    public decimal FreeShipping => decimal.Parse(cfg["Shop:FreeShippingThreshold"] ?? "200", System.Globalization.CultureInfo.InvariantCulture);

    public async Task<Dictionary<int, decimal>> DiscountPercents(IEnumerable<int> productIds)
    {
        var ids = productIds.Distinct().ToList(); var now = DateTime.UtcNow;
        var rows = await db.Campaigns.AsNoTracking()
            .Where(c => c.Enabled && c.StartsAt <= now && c.EndsAt >= now)
            .SelectMany(c => c.Products.Where(p => ids.Contains(p.Id)).Select(p => new { p.Id, c.Percent })).ToListAsync();
        return rows.GroupBy(r => r.Id).ToDictionary(g => g.Key, g => g.Max(x => x.Percent));
    }
    public static decimal Final(decimal price, decimal pct) => Math.Round(price * (100 - pct) / 100m, 2);

    public TotalsDto Totals(decimal subtotal, decimal shippingPrice)
    {
        var shipping = subtotal >= FreeShipping || subtotal == 0 ? 0 : shippingPrice;
        var tax = Math.Round(subtotal * TaxRate, 2);
        return new TotalsDto(subtotal, shipping, tax, subtotal + shipping + tax);
    }

    public async Task<List<int>> CategoryWithDescendants(int id)
    {
        var all = await db.Categories.AsNoTracking().Select(c => new { c.Id, c.ParentId }).ToListAsync();
        var res = new List<int> { id };
        for (int i = 0; i < res.Count; i++) res.AddRange(all.Where(c => c.ParentId == res[i]).Select(c => c.Id));
        return res;
    }

    public async Task<List<ProductDto>> ToDtos(List<Product> items)
    {
        var ids = items.Select(p => p.Id).ToList();
        var disc = await DiscountPercents(ids);
        var ratings = await db.Reviews.Where(r => ids.Contains(r.ProductId)).GroupBy(r => r.ProductId)
            .Select(g => new { Id = g.Key, Avg = g.Average(x => x.Rating), Cnt = g.Count() }).ToDictionaryAsync(x => x.Id);
        return items.Select(p =>
        {
            disc.TryGetValue(p.Id, out var pct); ratings.TryGetValue(p.Id, out var r);
            return new ProductDto(p.Id, p.Name, p.Description, p.Sku, p.Brand, p.Price, Final(p.Price, pct), pct, p.CategoryId,
                p.Category?.Name ?? "", p.StockQuantity,
                JsonSerializer.Deserialize<Dictionary<string, string>>(p.SpecificationsJson) ?? new(),
                p.Images.OrderBy(i => i.SortOrder).Select(i => i.Url).ToList(), r == null ? 0 : Math.Round(r.Avg, 1), r?.Cnt ?? 0);
        }).ToList();
    }

    /// მარაგის კრიტიკულ ზღვარზე შეტყობინება (SaveChanges გამოიძახეთ გარეთ)
    public void NotifyIfLow(Product p)
    {
        if (p.StockQuantity <= p.MinStockThreshold)
            db.Notifications.Add(new Notification { Type = "LowStock", Message = $"დაბალი მარაგი: \"{p.Name}\" — დარჩენილია {p.StockQuantity} (ზღვარი {p.MinStockThreshold})" });
    }
}

/// ფასდაკლების კამპანიების ავტომატური გააქტიურება/დასრულება
public class CampaignWorker(IServiceScopeFactory sf, ILogger<CampaignWorker> log) : BackgroundService
{
    protected override async Task ExecuteAsync(CancellationToken ct)
    {
        while (!ct.IsCancellationRequested)
        {
            try
            {
                using var scope = sf.CreateScope();
                var db = scope.ServiceProvider.GetRequiredService<AppDbContext>(); var now = DateTime.UtcNow;
                foreach (var c in await db.Campaigns.ToListAsync(ct))
                {
                    var active = c.Enabled && c.StartsAt <= now && c.EndsAt >= now;
                    if (active == c.IsActive) continue;
                    c.IsActive = active;
                    db.Notifications.Add(new Notification { Type = "Campaign", Message = $"კამპანია \"{c.Name}\" {(active ? "გააქტიურდა" : "დასრულდა")}" });
                }
                await db.SaveChangesAsync(ct);
            }
            catch (Exception ex) { log.LogError(ex, "CampaignWorker failed"); }
            await Task.Delay(TimeSpan.FromMinutes(1), ct);
        }
    }
}
