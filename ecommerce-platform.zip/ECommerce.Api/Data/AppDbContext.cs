using ECommerce.Api.Models;
using Microsoft.EntityFrameworkCore;
namespace ECommerce.Api.Data;

public class AppDbContext(DbContextOptions<AppDbContext> o) : DbContext(o)
{
    public DbSet<User> Users => Set<User>();
    public DbSet<Address> Addresses => Set<Address>();
    public DbSet<Category> Categories => Set<Category>();
    public DbSet<Product> Products => Set<Product>();
    public DbSet<ProductImage> ProductImages => Set<ProductImage>();
    public DbSet<Campaign> Campaigns => Set<Campaign>();
    public DbSet<Review> Reviews => Set<Review>();
    public DbSet<WishlistItem> Wishlist => Set<WishlistItem>();
    public DbSet<CartItem> CartItems => Set<CartItem>();
    public DbSet<DeliveryMethod> DeliveryMethods => Set<DeliveryMethod>();
    public DbSet<Order> Orders => Set<Order>();
    public DbSet<OrderItem> OrderItems => Set<OrderItem>();
    public DbSet<Notification> Notifications => Set<Notification>();

    protected override void ConfigureConventions(ModelConfigurationBuilder b) => b.Properties<decimal>().HavePrecision(18, 2);

    protected override void OnModelCreating(ModelBuilder m)
    {
        m.Entity<User>().HasIndex(u => u.Email).IsUnique();
        m.Entity<Category>().HasOne(c => c.Parent).WithMany(c => c.Children).HasForeignKey(c => c.ParentId).OnDelete(DeleteBehavior.Restrict);
        m.Entity<Product>().HasIndex(p => p.Sku).IsUnique().HasFilter("[Sku] IS NOT NULL");
        m.Entity<Product>().HasOne(p => p.Category).WithMany().HasForeignKey(p => p.CategoryId).OnDelete(DeleteBehavior.Restrict);
        m.Entity<Product>().HasIndex(p => new { p.CategoryId, p.Brand, p.Price });
        m.Entity<Product>().ToTable(t => t.HasCheckConstraint("CK_Product_Price", "[Price] >= 0"));
        m.Entity<Review>().HasIndex(r => new { r.ProductId, r.UserId }).IsUnique();
        m.Entity<Review>().HasOne<Product>().WithMany().HasForeignKey(r => r.ProductId);
        m.Entity<WishlistItem>().HasKey(w => new { w.UserId, w.ProductId });
        m.Entity<CartItem>().HasIndex(c => new { c.UserId, c.ProductId }).IsUnique();
        m.Entity<OrderItem>().HasOne(i => i.Product).WithMany().HasForeignKey(i => i.ProductId).OnDelete(DeleteBehavior.Restrict);
        m.Entity<Order>().HasOne(o => o.User).WithMany().HasForeignKey(o => o.UserId).OnDelete(DeleteBehavior.Restrict);
        m.Entity<Order>().HasOne(o => o.DeliveryMethod).WithMany().HasForeignKey(o => o.DeliveryMethodId).OnDelete(DeleteBehavior.Restrict);
        m.Entity<Order>().HasIndex(o => new { o.UserId, o.CreatedAt });
        m.Entity<DeliveryMethod>().HasData(
            new DeliveryMethod { Id = 1, Name = "სტანდარტული მიწოდება", Price = 8, EstimatedDays = 3 },
            new DeliveryMethod { Id = 2, Name = "ექსპრეს მიწოდება", Price = 15, EstimatedDays = 1 },
            new DeliveryMethod { Id = 3, Name = "ფილიალიდან გატანა", Price = 0, EstimatedDays = 0 });
    }
}
