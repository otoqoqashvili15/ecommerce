using System.Text;
using ECommerce.Api.Data;
using ECommerce.Api.Models;
using ECommerce.Api.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;

var b = WebApplication.CreateBuilder(args);
b.Services.AddDbContext<AppDbContext>(o => o.UseSqlServer(b.Configuration.GetConnectionString("Default")));
b.Services.AddScoped<TokenService>();
b.Services.AddScoped<CatalogService>();
b.Services.AddScoped<IPaymentGateway, FakePaymentGateway>();
b.Services.AddHostedService<CampaignWorker>();
b.Services.AddControllers();
b.Services.AddCors(o => o.AddDefaultPolicy(p => p.WithOrigins("http://localhost:4200").AllowAnyHeader().AllowAnyMethod()));
b.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(o =>
    o.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true, ValidateAudience = true, ValidateLifetime = true, ValidateIssuerSigningKey = true,
        ValidIssuer = b.Configuration["Jwt:Issuer"], ValidAudience = b.Configuration["Jwt:Audience"],
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(b.Configuration["Jwt:Key"]!))
    });
b.Services.AddAuthorization();
b.Services.AddEndpointsApiExplorer();
b.Services.AddSwaggerGen(c =>
{
    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme { Type = SecuritySchemeType.Http, Scheme = "bearer", BearerFormat = "JWT" });
    c.AddSecurityRequirement(new OpenApiSecurityRequirement {{
        new OpenApiSecurityScheme { Reference = new OpenApiReference { Type = ReferenceType.SecurityScheme, Id = "Bearer" } }, Array.Empty<string>() }});
});

var app = b.Build();
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    db.Database.EnsureCreated();   // production-ში გამოიყენეთ EF migrations
    if (!db.Users.Any())
    {
        db.Users.Add(new User { Email = app.Configuration["Seed:AdminEmail"]!, FullName = "Administrator", Role = Roles.Admin,
            PasswordHash = BCrypt.Net.BCrypt.HashPassword(app.Configuration["Seed:AdminPassword"]!) });
        db.SaveChanges();
    }
}
app.UseSwagger(); app.UseSwaggerUI();
app.UseHttpsRedirection();
app.UseCors();
app.UseAuthentication(); app.UseAuthorization();
app.MapControllers();
app.Run();
