using System.ComponentModel.DataAnnotations;
namespace ECommerce.Api.Models;

public static class Roles
{
    public const string Admin = "Admin", Manager = "Manager", Customer = "Customer";
    public const string Staff = "Admin,Manager";
}
public enum OrderStatus { Pending, Paid, Processing, Shipped, Delivered, Cancelled }

public class User
{
    public int Id { get; set; }
    [MaxLength(200)] public string Email { get; set; } = "";
    public string PasswordHash { get; set; } = "";
    [MaxLength(200)] public string FullName { get; set; } = "";
    [MaxLength(30)] public string? Phone { get; set; }
    [MaxLength(20)] public string Role { get; set; } = Roles.Customer;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
public class Address
{
    public int Id { get; set; }
    public int UserId { get; set; }
    [MaxLength(50)] public string Label { get; set; } = "Home";
    [MaxLength(100)] public string City { get; set; } = "";
    [MaxLength(300)] public string Street { get; set; } = "";
    [MaxLength(20)] public string? PostalCode { get; set; }
    public bool IsDefault { get; set; }
}
public class Category
{
    public int Id { get; set; }
    [MaxLength(150)] public string Name { get; set; } = "";
    public int? ParentId { get; set; }
    public Category? Parent { get; set; }
    public List<Category> Children { get; set; } = new();
}
public class Product
{
    public int Id { get; set; }
    [MaxLength(250)] public string Name { get; set; } = "";
    public string Description { get; set; } = "";
    [MaxLength(60)] public string? Sku { get; set; }
    [MaxLength(100)] public string Brand { get; set; } = "";
    public decimal Price { get; set; }
    public int CategoryId { get; set; }
    public Category Category { get; set; } = null!;
    public int StockQuantity { get; set; }
    public int MinStockThreshold { get; set; } = 5;
    public string SpecificationsJson { get; set; } = "{}";
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    [Timestamp] public byte[]? RowVersion { get; set; }
    public List<ProductImage> Images { get; set; } = new();
    public List<Campaign> Campaigns { get; set; } = new();
}
public class ProductImage
{
    public int Id { get; set; }
    public int ProductId { get; set; }
    [MaxLength(500)] public string Url { get; set; } = "";
    public int SortOrder { get; set; }
}
public class Campaign
{
    public int Id { get; set; }
    [MaxLength(200)] public string Name { get; set; } = "";
    public decimal Percent { get; set; }
    public DateTime StartsAt { get; set; }
    public DateTime EndsAt { get; set; }
    public bool Enabled { get; set; } = true;
    public bool IsActive { get; set; }          // ავტომატურად აახლებს CampaignWorker
    public List<Product> Products { get; set; } = new();
}
public class Review
{
    public int Id { get; set; }
    public int ProductId { get; set; }
    public int UserId { get; set; }
    public User User { get; set; } = null!;
    public int Rating { get; set; }
    [MaxLength(2000)] public string Comment { get; set; } = "";
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
public class WishlistItem { public int UserId { get; set; } public int ProductId { get; set; } public Product Product { get; set; } = null!; }
public class CartItem
{
    public int Id { get; set; }
    public int UserId { get; set; }
    public int ProductId { get; set; }
    public Product Product { get; set; } = null!;
    public int Quantity { get; set; }
}
public class DeliveryMethod
{
    public int Id { get; set; }
    [MaxLength(100)] public string Name { get; set; } = "";
    public decimal Price { get; set; }
    public int EstimatedDays { get; set; }
}
public class Order
{
    public int Id { get; set; }
    public int UserId { get; set; }
    public User User { get; set; } = null!;
    public OrderStatus Status { get; set; } = OrderStatus.Pending;
    public decimal Subtotal { get; set; }
    public decimal ShippingCost { get; set; }
    public decimal Tax { get; set; }
    public decimal Total { get; set; }
    public int DeliveryMethodId { get; set; }
    public DeliveryMethod DeliveryMethod { get; set; } = null!;
    [MaxLength(600)] public string ShippingAddress { get; set; } = "";
    [MaxLength(30)] public string PaymentMethod { get; set; } = "";
    [MaxLength(100)] public string? PaymentReference { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    public List<OrderItem> Items { get; set; } = new();
}
public class OrderItem
{
    public int Id { get; set; }
    public int OrderId { get; set; }
    public Order Order { get; set; } = null!;
    public int ProductId { get; set; }
    public Product Product { get; set; } = null!;
    [MaxLength(250)] public string ProductName { get; set; } = "";
    public decimal UnitPrice { get; set; }
    public int Quantity { get; set; }
}
public class Notification
{
    public int Id { get; set; }
    [MaxLength(40)] public string Type { get; set; } = "";
    [MaxLength(500)] public string Message { get; set; } = "";
    public bool IsRead { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
